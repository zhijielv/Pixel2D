package v2tov3

import "github.com/davyxu/golog"

var log = golog.New("v2tov3")

func init() {
	log.SetParts()
}
