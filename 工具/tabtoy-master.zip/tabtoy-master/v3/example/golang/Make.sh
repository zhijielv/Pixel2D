#!/usr/bin/env bash

go run main.go table_gen.go