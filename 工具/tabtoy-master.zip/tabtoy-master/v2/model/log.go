package model

import (
	"github.com/davyxu/golog"
)

var log *golog.Logger = golog.New("model")

const TypeSheetName = "@Types"
