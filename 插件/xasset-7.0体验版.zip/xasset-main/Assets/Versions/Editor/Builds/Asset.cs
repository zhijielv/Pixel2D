﻿using System;

namespace Versions.Editor.Builds
{
    [Serializable]
    public class Asset
    {
        public string path;
        public string bundle;
    }
}