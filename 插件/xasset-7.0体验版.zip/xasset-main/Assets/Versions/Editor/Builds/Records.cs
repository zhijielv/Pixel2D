﻿using System.Collections.Generic;
using UnityEngine;

namespace Versions.Editor.Builds
{
    public class Records : ScriptableObject
    {
        public List<Record> data = new List<Record>();
    }
}