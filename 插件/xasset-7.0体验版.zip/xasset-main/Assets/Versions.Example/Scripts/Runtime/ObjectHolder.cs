﻿using UnityEngine;

namespace Versions.Example
{
    public class ObjectHolder : MonoBehaviour
    {
        public Object[] objects;
    }
}